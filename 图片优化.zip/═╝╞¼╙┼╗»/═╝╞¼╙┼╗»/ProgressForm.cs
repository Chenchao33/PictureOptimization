﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 图片优化
{
    public partial class ProgressForm : Form
    {
        public ProgressForm()
        {
            InitializeComponent();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            Visitor.progressBarValue = 0;
            BackgroundWorker worker = sender as BackgroundWorker;
            string[] pramlist = (string[])e.Argument;
            int arryNum = 0;
            string path = Visitor.picturePath;
            string[] arry1 = path.Split('\\');
            arryNum = arry1.Length;
            foreach (string str in Visitor.pictureName)
            {
                if (worker.CancellationPending)
                {
                    e.Cancel = true;
                }
                else
                {
                    string[] arry2 = str.Split('\\');
                    int arryi2 = arry2.Length;
                    string strPath = "";
                    for (int j = arryNum; j < arryi2; j++)
                    {
                        strPath += "\\" + arry2[j];
                    }
                    HelperClass.CreateImageFromBytes(Visitor.depositPath + strPath, HelperClass.GetThumbnailImg(str, "jpeg", Visitor.pictureWith, Visitor.pictureHigh));
                    Visitor.progressBarValue++;
                    e.Result = DownLoad(Visitor.progressBarValue, worker, e, pramlist);
                }
            }
        }

        private bool DownLoad(int i, BackgroundWorker worker, DoWorkEventArgs e, string[] pramlist)
        {
            worker.ReportProgress(i);
            Visitor.progressBarValue = i;
            return true;
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progressBar1.Maximum = Visitor.Sum;
            progressBar1.Value = e.ProgressPercentage;  
            bool scroll = false;
            if (this.listBox1.TopIndex == this.listBox1.Items.Count - (int)(this.listBox1.Height / this.listBox1.ItemHeight))
            {
                scroll = true;
            }
            listBox1.Items.Add(Visitor.pictureName[e.ProgressPercentage - 1]);
            if (scroll)
            {
                this.listBox1.TopIndex = this.listBox1.Items.Count - (int)(this.listBox1.Height / this.listBox1.ItemHeight);
            }
            label1.Text = string.Format("总共：{0}张图片，处理完，{1}张", Visitor.Sum.ToString(), e.ProgressPercentage);
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                label1.Text = "优化已结束！";
            }
            else
            {
                Visitor.isDone = true;
                label1.Text = "优化成功！请关闭窗口。";
            }
        }

        private void ProgressForm_Load(object sender, EventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();
        }

        private void ProgressForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!Visitor.isDone)
            {
                DialogResult result = MessageBox.Show("图片处理未完成！\n是否关闭？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result == DialogResult.Yes)
                {
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }

        private void ProgressForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            backgroundWorker1.CancelAsync();
            backgroundWorker1.Dispose();
        }
    }
}
