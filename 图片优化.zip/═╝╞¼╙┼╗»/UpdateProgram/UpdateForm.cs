﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace UpdateProgram
{
    public partial class UpdateForm : Form
    {
        public UpdateForm()
        {
            InitializeComponent();
        }

        #region 控件事件
        private void UpdateForm_Load(object sender, EventArgs e)
        {
            Visitor.isDone = true;
            button1.Text = "更新";
        }

        private void UpdateForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!Visitor.isDone)
            {
                DialogResult result = MessageBox.Show("更新未完成！\n是否关闭？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result == DialogResult.Yes)
                {
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }

        int count = 0;
        private void button1_Click(object sender, EventArgs e)
        {         
            count++;
            switch (count)
            {
                case 1:
                    label2.Text = "";
                    Visitor.isDone = false;//表示更新已经开始
                    Process[] processes = Process.GetProcesses();
                    foreach (Process p in processes)
                    {
                        if (p.ProcessName == "图片优化")
                        {
                            p.Kill();
                        }
                    }
                    if (backgroundWorker1.IsBusy)
                    {
                        return;
                    }
                    string[] pramlist = { "100" };
                    backgroundWorker1.RunWorkerAsync(pramlist);
                    button1.Enabled = false;
                    break;
                case 2:                
                    this.Dispose();
                    backgroundWorker1.Dispose();
                    Process.Start(AppDomain.CurrentDomain.BaseDirectory + "图片优化.exe");
                    this.Close();
                    break;
            }           
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;
            string[] pramlist = (string[])e.Argument;
            e.Result = DownLoad(1, worker, e, pramlist);
            bool dof = DeleteOldFile();
            if (dof)
            {
                e.Result = DownLoad(2, worker, e, pramlist);
                bool dad = DownloadAndDecompress();
                if (dad)
                {
                    e.Result = DownLoad(3, worker, e, pramlist);
                    bool dzf = DeleteZipFile();
                    if (dzf)
                    {
                        e.Result = DownLoad(4, worker, e, pramlist);
                        CopyDirectory(AppDomain.CurrentDomain.BaseDirectory);//更新配置文件
                    }
                    else
                    {
                        e.Result = false;
                    }
                }
                else
                {
                    e.Result = false;
                }
            }
            else
            {
                e.Result = false;
            }
        }

        private bool DownLoad(int num, BackgroundWorker worker, DoWorkEventArgs e, string[] pramlist)
        {
            if (num == 1)
            {
                for (int i = 0; i < 20; i++)
                {
                    worker.ReportProgress(i, "更新开始");
                    Thread.Sleep(200);
                    Visitor.progressBarValue = i;
                }
            }
            else if (num == 2)
            {
                for (int i = 20; i < 50; i++)
                {
                    worker.ReportProgress(i, "更新开始");
                    Thread.Sleep(150);
                    Visitor.progressBarValue = i;
                }
            }
            else if (num == 3)
            {
                for (int i = 50; i < 90; i++)
                {
                    worker.ReportProgress(i, "更新开始");
                    Thread.Sleep(100);
                    Visitor.progressBarValue = i;
                }
            }
            else
            {
                for (int i = 90; i <= 100; i++)
                {
                    worker.ReportProgress(i, "更新开始");
                    Thread.Sleep(50);
                    Visitor.progressBarValue = i;
                }
            }
            return true;
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
            label2.Text = string.Format("{0}，更新中{1}%", e.UserState.ToString(), e.ProgressPercentage);
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (bool.Parse(e.Result.ToString()))
            {
                this.progressBar1.Value = 100;
                label2.Text = "更新成功！请点击完成。";
                Visitor.isDone = true;
                button1.Enabled = true;
                button1.Text = "完成";
            }
            else
            {
                this.progressBar1.Value = Visitor.progressBarValue;
                label2.Text = "更新失败！请联系管理员。";
                Visitor.isDone = true;
                button1.Enabled = true;
                button1.Text = "关闭";
            }            
        }
        #endregion

        #region 主要函数
        /// <summary>
        /// 删除原来的文件
        /// </summary>
        /// <returns>操作是否成功</returns>
        private bool DeleteOldFile()
        {
            try
            {
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "图片优化.exe"))
                {
                    File.Delete(AppDomain.CurrentDomain.BaseDirectory + "图片优化.exe");
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// 下载并解压文件
        /// </summary>
        private bool DownloadAndDecompress()
        {
            try
            {
                string updateFtpPath = "***********/图片优化.zip";//ftp上更新包的地址//要改成更新包的ftp地址
                //更新
                HelperClass.download(updateFtpPath, Application.StartupPath, "图片优化");
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// 删除压缩包
        /// </summary>
        private bool DeleteZipFile()
        {
            try
            {
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "图片优化.zip"))
                {
                    File.Delete(AppDomain.CurrentDomain.BaseDirectory + "图片优化.zip");
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// 配置文件的拷贝
        /// </summary>
        /// <param name="destPath">目标文件目录</param>
        private static void CopyDirectory(string destPath)
        {
            try
            {
                string tempFolder = AppDomain.CurrentDomain.BaseDirectory + "Temp";//临时文件夹
                DirectoryInfo dir = new DirectoryInfo(tempFolder);
                FileSystemInfo[] fileinfo = dir.GetFileSystemInfos(); //获取目录下（不包含子目录）的文件和子目录
                foreach (FileSystemInfo i in fileinfo)
                {
                    if (i is DirectoryInfo) //判断是否文件夹
                    {
                        if (!Directory.Exists(destPath + "\\" + i.Name))
                        {
                            Directory.CreateDirectory(destPath + "\\" + i.Name);//目标目录下不存在此文件夹即创建子文件夹
                        }
                        File.Copy(i.FullName, destPath + "\\" + i.Name);//递归调用复制子文件夹
                    }
                    else
                    {
                        File.Copy(i.FullName, destPath + "\\" + i.Name, true); //不是文件夹即复制文件，true表示可以覆盖同名文件
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        #endregion
    }
}
