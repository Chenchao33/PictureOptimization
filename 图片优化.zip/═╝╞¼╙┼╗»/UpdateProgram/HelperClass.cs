﻿using ICSharpCode.SharpZipLib.Zip;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace UpdateProgram
{
    class HelperClass
    {
        /// <summary>
        /// ftp下载
        /// </summary>
        /// <param name="ftpPath">ftp地址</param>
        /// <param name="filePath">下载路径</param>
        public static void download(string ftpPath, string filePath, string dirName)
        {
            string path = filePath + "\\" + dirName;//原有文件路径
            //删除原有的文件，确保更新的一致性
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
            }
            /*首先从配置文件读取ftp的登录信息*/
            string FtpUserName = "*********";//这里需要改成ftp的用户名
            string FtpPassWord = "*********";//这里需要改成ftp的密码
            Uri uri = new Uri(ftpPath);
            string FileName = Path.GetFullPath(filePath) + Path.DirectorySeparatorChar.ToString() + Path.GetFileName(uri.LocalPath);
            FileStream fs = null;//创建一个文件流
            Stream responseStream = null;
            try
            {
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(uri);//创建一个与FTP服务器联系的FtpWebRequest对象                
                request.Method = WebRequestMethods.Ftp.DownloadFile;//设置请求的方法是FTP文件下载                
                request.Credentials = new NetworkCredential(FtpUserName, FtpPassWord);//连接登录FTP服务器                
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();//获取一个请求响应对象                
                responseStream = response.GetResponseStream();//获取请求的响应流            
                if (File.Exists(FileName))//判断本地文件是否存在，如果存在，则打开和重写本地文件
                {
                    fs = File.Open(FileName, FileMode.Open, FileAccess.ReadWrite);
                }
                else//判断本地文件是否存在，如果不存在，则创建本地文件
                {
                    fs = File.Create(FileName);
                }
                if (fs != null)
                {
                    int buffer_count = 65536;
                    byte[] buffer = new byte[buffer_count];
                    int size = 0;
                    while ((size = responseStream.Read(buffer, 0, buffer_count)) > 0)
                    {
                        fs.Write(buffer, 0, size);
                    }
                    fs.Flush();
                    fs.Close();
                    responseStream.Close();
                }
            }
            finally
            {
                if (fs != null)
                    fs.Close();
                if (responseStream != null)
                    responseStream.Close();
            }
            FileStream FS = new FileStream(FileName, FileMode.Open, FileAccess.Read);
            BinaryReader reader = new BinaryReader(FS);
            string fileclass = "";
            for (int i = 0; i < 2; i++)
            {
                fileclass += reader.ReadByte().ToString();
            }
            reader.Close();
            FS.Close();
            if (fileclass == "8075")
            {
                #region 解压
                /// <summary>   
                /// 功能：解压zip格式的文件。   
                /// </summary>   
                /// <param name="zipFilePath">压缩文件路径，全路径格式</param>   
                /// <param name="unZipDir">解压文件存放路径,全路径格式，为空时默认与压缩文件同一级目录下，跟压缩文件同名的文件夹</param>   
                /// <param name="err">出错信息</param>  
                /// <returns>解压是否成功</returns>
                string unZipDir = "";
                if (FileName == string.Empty)
                {
                    throw new FileNotFoundException("压缩文件不不能为空！");
                }

                if (!File.Exists(FileName))
                {
                    throw new FileNotFoundException("压缩文件: " + FileName + " 不存在!");
                }
                //解压文件夹为空时默认与压缩文件同一级目录下，跟压缩文件同名的文件夹  
                if (unZipDir == string.Empty)
                    unZipDir = FileName.Replace(Path.GetFileName(FileName), "");
                if (!unZipDir.EndsWith("//"))
                    unZipDir += "//";
                if (!Directory.Exists(unZipDir))
                    Directory.CreateDirectory(unZipDir);
                using (ZipInputStream s = new ZipInputStream(File.OpenRead(FileName)))
                {
                    ZipEntry theEntry;
                    while ((theEntry = s.GetNextEntry()) != null)
                    {
                        string directoryName = Path.GetDirectoryName(theEntry.Name);
                        string fileName = Path.GetFileName(theEntry.Name);
                        if (directoryName.Length > 0)
                        {
                            Directory.CreateDirectory(unZipDir + directoryName);
                        }
                        if (!directoryName.EndsWith("//"))
                            directoryName += "//";
                        if (fileName != String.Empty)
                        {
                            using (FileStream streamWriter = File.Create(unZipDir + theEntry.Name))
                            {
                                int size = 2048;
                                byte[] data = new byte[2048];
                                while (true)
                                {
                                    size = s.Read(data, 0, data.Length);
                                    if (size > 0)
                                    {
                                        streamWriter.Write(data, 0, size);
                                    }
                                    else
                                    {

                                        break;
                                    }
                                }
                                streamWriter.Close();
                            }
                        }
                    }
                    s.Close();
                }
                #endregion
            }
        }
    }
}
