﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 图片优化
{
    class Visitor
    {
        private static int progressbarvalue;
        /// <summary>
        /// 进度条的值
        /// </summary>
        public static int progressBarValue
        {
            get
            {
                return progressbarvalue;
            }
            set
            {
                progressbarvalue = value;
            }
        }

        private static int sum;
        /// <summary>
        /// 进度条的值
        /// </summary>
        public static int Sum
        {
            get
            {
                return sum;
            }
            set
            {
                sum = value;
            }
        }

        private static string picturepath;
        /// <summary>
        /// 图片地址
        /// </summary>
        public static string picturePath
        {
            get
            {
                return picturepath;
            }
            set
            {
                picturepath = value;
            }
        }

        private static string depositpath;
        /// <summary>
        /// 图片存放地址
        /// </summary>
        public static string depositPath
        {
            get
            {
                return depositpath;
            }
            set
            {
                depositpath = value;
            }
        }

        private static int picturewith;
        /// <summary>
        /// 设置图片宽度
        /// </summary>
        public static int pictureWith
        {
            get
            {
                return picturewith;
            }
            set
            {
                picturewith = value;
            }
        }

        private static int picturehigh;
        /// <summary>
        /// 设置图片高度
        /// </summary>
        public static int pictureHigh
        {
            get
            {
                return picturehigh;
            }
            set
            {
                picturehigh = value;
            }
        }

        private static List<string> picturename;
        /// <summary>
        /// 所有图片的路径及名称
        /// </summary>
        public static List<string> pictureName
        {
            get
            {
                return picturename;
            }
            set
            {
                picturename = value;
            }
        }

        private static bool isdone;
        /// <summary>
        /// 判断图片处理是否开始或者已经完成
        /// </summary>
        public static bool isDone
        {
            get
            {
                return isdone;
            }
            set
            {
                isdone = value;
            }
        }
    }
}
