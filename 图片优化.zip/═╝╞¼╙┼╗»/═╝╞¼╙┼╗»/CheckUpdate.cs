﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace 图片优化
{
    class CheckUpdate
    {
        /// <summary>
        /// 获取配置文件的信息
        /// </summary>
        /// <param name="path">文件路径</param>
        /// <param name="fileName">文件名称</param>
        /// <param name="nodeName">节点名称</param>
        /// <param name="attributeName">属性名称</param>
        /// <returns>属性值</returns>
        static string GetVersionInfo(string path, string fileName, string nodeName, string attributeName)
        {
            string attributeValue = "";
            string xmlPath = path + "\\" + fileName + ".xml";
            XmlDocument doc = new XmlDocument();
            doc.Load(xmlPath);
            XmlNode root = doc.SelectSingleNode(nodeName);
            foreach (XmlNode nd in root.ChildNodes)
            {
                XmlElement element = (XmlElement)nd;
                attributeValue = element.GetAttribute(attributeName).ToString();
            }
            return attributeValue;
        }

        public static void Check()
        {
            string tempFolder = AppDomain.CurrentDomain.BaseDirectory + "Temp";//临时文件夹
            HelperClass.CreateTemp(tempFolder);//创建或者清空temp文件夹
            HelperClass.download("ftp://36.22.183.102:21/chenchao/CC/update.xml", tempFolder, "cc");//下载ftp上的配置文件
            string ftpDate = GetVersionInfo(tempFolder, "update", "AutoUpdater", "Date");
            string currentDate = GetVersionInfo(Application.StartupPath, "update", "AutoUpdater", "Date");
            if (Convert.ToDateTime(currentDate) >= Convert.ToDateTime(ftpDate))
            {
                MainForm mainform = new MainForm();
                mainform.ShowDialog();
            }
            else
            {
                Process.Start(AppDomain.CurrentDomain.BaseDirectory + "UpdateProgram.exe");
            }
        }
    }
}
