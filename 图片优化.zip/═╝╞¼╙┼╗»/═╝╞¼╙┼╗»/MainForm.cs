﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 图片优化
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        #region 控件事件

        private void MainForm_Load(object sender, EventArgs e)
        {
            Visitor.isDone = true;
            label2.Text = "总共：" + Visitor.Sum.ToString() + "张图片";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("图片地址不能为空！！");
            }
            else
            {
                if (textBox2.Text == "")
                {
                    MessageBox.Show("存放地址不能为空！！");
                }
                else
                {
                    if (Visitor.Sum == 0)
                    {
                        MessageBox.Show("没有可以优化的图片，请重新选择图片地址！！");
                    }
                    else
                    {
                        if (textBox1.Text == textBox2.Text)
                        {
                            MessageBox.Show("图片地址不能与存放地址相同！！");
                        }
                        else
                        {
                            if (pictureSize())
                            {
                                Visitor.isDone = false;
                                ProgressForm pf = new ProgressForm();
                                pf.ShowDialog();
                            }
                            else
                            {
                                MessageBox.Show("单位转换出错！！");
                            }
                        }                     
                    }                  
                }
            }            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择图片文件路径：";
            if (textBox1.Text != "")
            {
                dialog.SelectedPath = textBox1.Text;
            }          
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Visitor.picturePath = dialog.SelectedPath;
            }
            textBox1.Text = Visitor.picturePath;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择图片文件存放路径：";
            if (textBox2.Text != "")
            {
                dialog.SelectedPath = textBox2.Text;
            }
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Visitor.depositPath = dialog.SelectedPath;
            }
            textBox2.Text = Visitor.depositPath;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();//执行后台操作
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == textBox2.Text)
            {
                MessageBox.Show("该地址不能与图片地址相同！！");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();//执行后台操作
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                label8.Text = "px";
                label9.Text = "px";
            }
            else
            {
                label8.Text = "mm";
                label9.Text = "mm";
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            Visitor.Sum = 0;
            string path = Visitor.picturePath;
            Visitor.pictureName = FindImage(path);
            foreach (string str in Visitor.pictureName)
            {
                Visitor.Sum++;
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            label2.Text = "总共：" + Visitor.Sum.ToString() + "张图片";
        }

        #endregion

        #region 主要函数

        /// <summary>
        /// 遍历图片
        /// </summary>
        /// <param name="sSourcePath">图片路径</param>
        /// <returns>图片列表</returns>
        public List<string> FindImage(string sSourcePath)
        {
            List<String> list = new List<string>();
            if (sSourcePath != null)  
            {
                //遍历文件夹
                DirectoryInfo theFolder = new DirectoryInfo(sSourcePath);
                try
                {
                    FileInfo[] thefileInfo = theFolder.GetFiles("*.*", SearchOption.TopDirectoryOnly);
                    foreach (FileInfo nextfile in thefileInfo)  //遍历文件
                    {
                        string name = nextfile.Name.ToLower();
                        if (name.EndsWith(".jpg") || name.EndsWith(".jpeg") || name.EndsWith(".png"))
                        {
                            list.Add(nextfile.FullName);
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("无法读取该文件夹，请确保文件夹的可读取性！！");
                }
                if (checkBox1.Checked)//若选中穿透目录
                {
                    //遍历子文件夹
                    DirectoryInfo[] dirInfo = theFolder.GetDirectories();
                    try
                    {
                        foreach (DirectoryInfo NextFolder in dirInfo)
                        {
                            //list.Add(NextFolder.ToString());
                            FileInfo[] fileInfo = NextFolder.GetFiles("*.*", SearchOption.AllDirectories);
                            foreach (FileInfo nextfile in fileInfo)  //遍历文件
                            {
                                string name = nextfile.Name.ToLower();
                                if (name.EndsWith(".jpg") || name.EndsWith(".jpeg") || name.EndsWith(".png"))
                                {
                                    list.Add(nextfile.FullName);
                                }
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("无法读取该文件夹的子文件夹，请确保文件夹的可读取性！！");
                    }
                }
            }     
            return list;
        }

        /// <summary>
        /// 图片尺寸的单位转换
        /// </summary>
        /// <returns>操作结果</returns>
        private bool pictureSize()
        {
            try
            {
                if (radioButton1.Checked)
                {
                    Visitor.pictureWith = Convert.ToInt32(textBox3.Text);
                    Visitor.pictureHigh = Convert.ToInt32(textBox4.Text);
                }
                else if (radioButton2.Checked)
                {
                    Visitor.pictureWith = Convert.ToInt32(HelperClass.MillimetersToPixelsWidth(Convert.ToDouble(textBox3.Text)));
                    Visitor.pictureHigh = Convert.ToInt32(HelperClass.MillimetersToPixelsWidth(Convert.ToDouble(textBox3.Text)));
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion
    }
}
