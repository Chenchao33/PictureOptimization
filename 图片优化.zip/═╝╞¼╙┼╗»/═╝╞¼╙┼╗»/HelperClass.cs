﻿using ICSharpCode.SharpZipLib.Zip;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace 图片优化
{
    class HelperClass
    {
        /// <summary>
        /// 将毫米转换成像素
        /// </summary>
        /// <param name="length">长度毫米</param>
        /// <returns>长度像素</returns>
        public static double MillimetersToPixelsWidth(double length) //length是毫米，1厘米=10毫米
        {
            Panel p = new Panel();
            Graphics g = Graphics.FromHwnd(p.Handle);
            IntPtr hdc = g.GetHdc();
            int width = GetDeviceCaps(hdc, 4);// HORZRES 
            int pixels = GetDeviceCaps(hdc, 8);// BITSPIXEL
            g.ReleaseHdc(hdc);
            return (((double)pixels / (double)width) * (double)length);
        }
        [DllImport("gdi32.dll")]
        private static extern int GetDeviceCaps(IntPtr hdc, int Index);

        #region 图片优化方法

        public static byte[] ToByte(Image img)
        {
            ImageConverter imgconv = new ImageConverter();
            byte[] b = (byte[])imgconv.ConvertTo(img, typeof(byte[]));
            return b;
        }

        public static Stream ToStream(byte[] bytes)
        {
            Stream stream = new MemoryStream(bytes);
            return stream;
        }
        /// <summary>
        /// 获取等比缩略图
        /// </summary>
        /// <param name="urlORpath">原始url或绝对路径</param>
        /// <param name="contentType">HTTP MIME类型</param>
        /// <param name="maxWidth">最大宽度，为0时以高度最大值等比计算</param>
        /// <param name="maxHeight">最大高度，为0时以宽度最大值等比计算</param>
        /// <param name="tianChongSe">补齐填充色</param>
        /// <param name="yasuo">图片为JPG时，设置压缩的比例1-100</param>
        public static byte[] GetThumbnailImg(string urlORpath, string contentType, int maxWidth, int maxHeight, string tianChongSe = "", int yaSuo = 95)
        {
            tianChongSe = (!string.IsNullOrEmpty(tianChongSe) ? ("#" + tianChongSe) : "");
            if (yaSuo < 0)
            {
                yaSuo = 1;
            }
            else if (yaSuo == 0)
            {
                yaSuo = 95;
            }
            else if (yaSuo > 100)
            {
                yaSuo = 100;
            }
            if (!string.IsNullOrEmpty(urlORpath))
            {
                try
                {
                    byte[] data = ToByte(Image.FromFile(urlORpath));

                    if (maxWidth != 0 || maxHeight != 0)
                    {
                        data = GetThumbnailImg(ToStream(data), contentType, maxWidth, maxHeight, tianChongSe, yaSuo);
                    }
                    return data;
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
            return null;
        }

        /// <summary>
        /// 获取等比缩略图（直接调用待调试）
        /// </summary>
        /// <param name="stream">原图</param>
        /// <param name="contentType">HTTP MIME类型</param>
        /// <param name="maxWidth">最大宽度，为0时以高度最大值等比计算</param>
        /// <param name="maxHeight">最大高度，为0时以宽度最大值等比计算</param>
        /// <param name="tianChongSe">补齐填充色</param>
        /// <param name="yasuo">图片为JPG时，设置压缩的比例1-100</param>
        /// <returns></returns>
        public static byte[] GetThumbnailImg(Stream stream, string contentType, int maxWidth = 0, int maxHeight = 0, string tianChongSe = "", int yasuo = 95)
        {
            System.Drawing.Image img = System.Drawing.Image.FromStream(stream);
            Size newSize = new HelperClass().NewSize(maxWidth, maxHeight, img.Width, img.Height);

            float New_Width; // 新的宽度
            float New_Height; // 新的高度
            New_Width = newSize.Width;
            New_Height = newSize.Height;

            Bitmap yImgBmp = new Bitmap(img);
            System.Drawing.Image thumbnailImage = yImgBmp.GetThumbnailImage((int)New_Width, (int)New_Height, new System.Drawing.Image.GetThumbnailImageAbort(new HelperClass().ThumbnailCallback), IntPtr.Zero);
            yImgBmp = new Bitmap(thumbnailImage);

            if (maxWidth != 0 && maxHeight != 0 && tianChongSe != "")
            {
                Bitmap bmOutput = new Bitmap(maxWidth, maxHeight);
                Graphics gc = Graphics.FromImage(bmOutput);
                gc.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                gc.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                gc.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                SolidBrush tbBg = new SolidBrush(System.Drawing.ColorTranslator.FromHtml(tianChongSe));//补边
                gc.FillRectangle(tbBg, 0, 0, maxWidth, maxHeight); //补边
                int xPoint = 0;//若果要补边的话，原图像所在的x，y坐标。    
                int yPoint = 0;
                xPoint = (int)(((float)maxWidth - New_Width) / 2);
                yPoint = (int)(((float)maxHeight - New_Height) / 2);

                gc.DrawImage(yImgBmp, xPoint, yPoint, (int)New_Width, (int)New_Height);

                MemoryStream memoryStream = new MemoryStream();
                if (contentType == "jpeg")
                {
                    bmOutput.Save(memoryStream, GetImageCoderInfo("image/jpeg"), GetEP(yasuo));
                    return memoryStream.ToArray();
                }
                else
                {
                    bmOutput.Save(memoryStream, img.RawFormat);
                    return memoryStream.ToArray();
                }
            }
            else
            {
                if (contentType == "jpeg")
                {
                    MemoryStream memoryStream = new MemoryStream();
                    yImgBmp.Save(memoryStream, GetImageCoderInfo("image/jpeg"), GetEP(yasuo));
                    return memoryStream.ToArray();
                }
                else
                {
                    return ToByte(thumbnailImage);
                }
            }
        }

        private Size NewSize(int maxWidth, int maxHeight, int width, int height)
        {
            double w = Convert.ToDouble(width);
            double h = Convert.ToDouble(height);
            double sw = w;
            double sh = h;
            double mw = Convert.ToDouble(maxWidth);
            double mh = Convert.ToDouble(maxHeight);

            if (mw != 0 && mh != 0)
            {
                if (sw < mw && sh < mh)
                {
                    w = sw;
                    h = sh;
                }
                else if ((sw / sh) > (mw / mh))
                {
                    w = maxWidth;
                    h = (w * sh) / sw;
                }
                else
                {
                    h = maxHeight;
                    w = (h * sw) / sh;
                }
            }
            else if (mh == 0 && w > maxWidth)
            {
                w = maxWidth;
                h = (w * sh) / sw;
            }
            else if (mw == 0 && h > maxHeight)
            {
                h = maxHeight;
                w = (h * sw) / sh;
            }

            return new Size(Convert.ToInt32(w), Convert.ToInt32(h));
        }

        private bool ThumbnailCallback()
        {
            return false;
        }

        /// <summary>
        /// 获取图片编码类型信息
        /// </summary>
        /// <param name="coderType">编码类型</param>
        /// <returns>ImageCodecInfo</returns>
        private static ImageCodecInfo GetImageCoderInfo(string coderType)
        {
            ImageCodecInfo[] iciS = ImageCodecInfo.GetImageEncoders();
            ImageCodecInfo retIci = null;
            foreach (ImageCodecInfo ici in iciS)
            {
                if (ici.MimeType.Equals(coderType))
                    retIci = ici;
            }
            return retIci;
        }

        /// <summary>
        /// JPG设置压缩质量
        /// </summary>
        /// <param name="i">设置压缩的比例1-100</param>
        /// <returns></returns>
        private static EncoderParameters GetEP(int i)
        {
            EncoderParameters ep = new EncoderParameters();
            long[] qy = new long[1];
            qy[0] = i;//设置压缩的比例1-100
            EncoderParameter eParam = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, qy);
            ep.Param[0] = eParam;
            return ep;
        }

        /// <summary>
        /// 将字节转换成图片
        /// </summary>
        /// <param name="buffer">字节流</param>
        /// <returns></returns>
        public static Image BytesToImage(byte[] buffer)
        {
            MemoryStream ms = new MemoryStream(buffer);
            Image image = Image.FromStream(ms);
            return image;
        }

        /// <summary>
        /// 将字节转换成图片并保存
        /// </summary>
        /// <param name="filePath">文件路径</param>
        /// <param name="buffer">字节流</param>
        public static void CreateImageFromBytes(string filePath, byte[] buffer)
        {
            Image image = BytesToImage(buffer);
            ImageFormat format = image.RawFormat;
            FileInfo info = new FileInfo(filePath);
            Directory.CreateDirectory(info.Directory.FullName);
            File.WriteAllBytes(filePath, buffer);
        }
        #endregion

        /// <summary>
        /// ftp下载
        /// </summary>
        /// <param name="ftpPath">ftp地址</param>
        /// <param name="filePath">下载路径</param>
        public static void download(string ftpPath, string filePath, string dirName)
        {
            string path = filePath + "\\" + dirName;//原有文件路径
            //删除原有的文件，确保更新的一致性
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
            }
            /*首先从配置文件读取ftp的登录信息*/
            string FtpUserName = "billdai";
            string FtpPassWord = "5Y3b87mK";
            Uri uri = new Uri(ftpPath);
            string FileName = Path.GetFullPath(filePath) + Path.DirectorySeparatorChar.ToString() + Path.GetFileName(uri.LocalPath);
            FileStream fs = null;//创建一个文件流
            Stream responseStream = null;
            try
            {
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(uri);//创建一个与FTP服务器联系的FtpWebRequest对象                
                request.Method = WebRequestMethods.Ftp.DownloadFile;//设置请求的方法是FTP文件下载                
                request.Credentials = new NetworkCredential(FtpUserName, FtpPassWord);//连接登录FTP服务器                
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();//获取一个请求响应对象                
                responseStream = response.GetResponseStream();//获取请求的响应流            
                if (File.Exists(FileName))//判断本地文件是否存在，如果存在，则打开和重写本地文件
                {
                    fs = File.Open(FileName, FileMode.Open, FileAccess.ReadWrite);
                }
                else//判断本地文件是否存在，如果不存在，则创建本地文件
                {
                    fs = File.Create(FileName);
                }
                if (fs != null)
                {
                    int buffer_count = 65536;
                    byte[] buffer = new byte[buffer_count];
                    int size = 0;
                    while ((size = responseStream.Read(buffer, 0, buffer_count)) > 0)
                    {
                        fs.Write(buffer, 0, size);
                    }
                    fs.Flush();
                    fs.Close();
                    responseStream.Close();
                }
            }
            finally
            {
                if (fs != null)
                    fs.Close();
                if (responseStream != null)
                    responseStream.Close();
            }
        }

        /// <summary>
        /// 判断是否存在temp文件夹，若不存在就新建，否则清空
        /// </summary>
        /// <param name="path">temp文件夹路径</param>
        public static void CreateTemp(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            else
            {
                Directory.Delete(path, true);
                Directory.CreateDirectory(path);
            }
        }
    }
}
