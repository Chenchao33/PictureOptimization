﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UpdateProgram
{
    class Visitor
    {
        private static bool isdone = false;
        /// <summary>
        /// 判断更新是否结束
        /// </summary>
        public static bool isDone
        {
            get
            {
                return isdone;
            }
            set
            {
                isdone = value;
            }
        }

        private static int progressbarvalue;
        /// <summary>
        /// 进度条的值
        /// </summary>
        public static int progressBarValue
        {
            get
            {
                return progressbarvalue;
            }
            set
            {
                progressbarvalue = value;
            }
        }
    }
}
